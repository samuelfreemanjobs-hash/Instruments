# DIRTY CIRCUITS — processing guide

Corruption bus for DiskLordz Black Box.

| Folder | Use |
|--------|-----|
| `01_PROCESS_MODES/CLEAN` | Era core as reference |
| `01_PROCESS_MODES/DIRTY` | Extra crush + cassette desk |
| `01_PROCESS_MODES/RUINED` | Extreme alias + drive + wow |
| `02_EXCLUSIVES_RUINED` | One-off ruined exclusives |

A/B CLEAN → DIRTY → RUINED of the same stem. Not a ROM dump.
