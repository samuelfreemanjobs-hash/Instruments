Mini-kit 01_SouthernCircuitry
Kick RAW / Glued / Cassette A/B + glued loop.
See _DOCS/Hardware_Processing_Guide.md
