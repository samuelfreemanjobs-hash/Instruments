Construction kit: glued oneshots + loop (+ MIDI if present).
