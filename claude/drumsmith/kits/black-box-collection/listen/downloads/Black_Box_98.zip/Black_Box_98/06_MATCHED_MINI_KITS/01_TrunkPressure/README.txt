Mini-kit 01_TrunkPressure
Kick RAW / Glued / Cassette A/B + glued loop.
See _DOCS/Hardware_Processing_Guide.md
