# BLACK BOX 98 — hardware / DAW processing guide

**Trunk Pressure** · DiskLordz Black Box — The Lost Drum Machine Collection

Producer instructions for this zip. Original synthesis only — not a hardware ROM dump.

## What's in this pack

| Folder | What it is |
|--------|------------|
| `01_CORE_ONESHOTS/` | RAW era cores |
| `02_BITCRUSHED_AND_PITCHED/` | Rate-dropped / pitched / aliased variants |
| `03_CASSETTE_AND_TAPE/` | Cassette desk FX (drive → tape LPF → wow/flutter → hiss) |
| `04_PARALLEL_PROCESS_BANKS/` | RAW / TAPE / LOFI / CASSETTE siblings |
| `05_LOOPS/` | Construction loops |
| `06_MATCHED_MINI_KITS/` | Oneshots + BPM loop + cassette kick A/B |
| `_DOCS/` | This guide + product notes |

## Rate-drop / pitched

1. Start from cores or use `02_BITCRUSHED_AND_PITCHED/RateDropped_808s/`.
2. Pitch down hard (−12 to −24 st) for crawling subs.
3. Shorten with choke so notes stay punchy under cassette compression.

## Cassette / tape grit

- Soft clip → HF roll-off → optional hiss from `03_CASSETTE_AND_TAPE/`.
- A/B RAW vs CASSETTE in `04_PARALLEL_PROCESS_BANKS/` before locking a pad.

## Parallel banks

Same hit, four ways: **RAW** · **TAPE** · **LOFI** · **CASSETTE**.

## Device notes

PCM16 mono @ 44.1 kHz. Device paths UNVERIFIED until logged.  
`release_ready` false until HITL. Pack root: `Black_Box_98/`
