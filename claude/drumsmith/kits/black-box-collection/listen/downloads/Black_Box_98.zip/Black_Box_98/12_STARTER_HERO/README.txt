Curated hero bank — fewer, deadlier hits than the full archive.
Prefer these for demos / store previews; full cores stay in 01_CORE_ONESHOTS.
