# BLACK BOX 96: Dirty Circuits Edition

Expanded flagship — clean-to-dirty variations + exclusives of the full BB96 oneshot set.

| Folder | What to do |
|--------|------------|
| `01_CLEAN_TO_DIRTY_PAIRS/<role>/CLEAN` | Map as your base pad |
| `01_CLEAN_TO_DIRTY_PAIRS/<role>/DIRTY` | Same hit, crushed/cassette dirt — layer or swap |
| `02_EXCLUSIVES_RUINED` | Extreme ruined one-offs |
| `03_CASSETTE_DESK` | Desk-only cassette pass (no extra bitcrush) |
| `04_LOOPS` | Construction loops from BB96 |

Stem names match across CLEAN / DIRTY / RUINED / CASS for easy pairing.
