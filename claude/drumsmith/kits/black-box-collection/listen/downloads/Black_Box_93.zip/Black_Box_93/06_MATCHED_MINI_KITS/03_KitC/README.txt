Mini-kit 03_KitC
Selected from masters — Kick vs Kick_Cassette A/B.
See _DOCS/Hardware_Processing_Guide.md
