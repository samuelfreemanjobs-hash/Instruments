Mini-kit 01_MemphisArchives
Selected from masters — Kick vs Kick_Cassette A/B.
See _DOCS/Hardware_Processing_Guide.md
